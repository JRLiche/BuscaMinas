package minesJRE.vista;

/**
 * Clase donde se encuentran los métodos de la parte visual del juego.
 */
public class Vista {

    /**
     * Método para mostrar el campo con las coordenadas.
     * @param camp campo que quieres mostrar al usuario.
     */
    public static void mostrarCampMines(char[][] camp){
        int fila = camp.length;
        int columna = camp[0].length;
        int contador = 1;
        char letra = 'A';
        System.out.print("   ");
        for (int i = 0; i < columna; i++) {
            if (contador > 9){
                System.out.print(contador + "  ");
                contador++;
            }else {
                System.out.print(contador + "   ");
                contador++;
            }
        }
        System.out.println();
        for (int i = 0; i < fila; ++i) {;
            System.out.print(letra + "  ");
            letra++;
            for (int j = 0; j < columna; ++j) {
                System.out.print(camp[i][j] + "   ");
            }
            System.out.println();
        }
    }

    /**
     * Método para mostrar un mensaje al usuario.
     * @param missatge mensaje que quieres mostrar.
     */
    public static void mostrarMissatge(String missatge){
        System.out.println(missatge);
    }

}
