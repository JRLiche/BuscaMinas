package minesJRE.model;
import minesJRE.vista.Vista;

/**
 * Clase donde se encuentran los métodos de la parte interna del juego.
 */
public class Model {

    static int files, columnes, bombes;
    static char[][] minesOcult, minesVisible;
    static boolean jocFinalitzat = false;

    /**
     * Método donde se inicializa el juego y se crean los campos de minas.
     * @param f son las filas del campo de minas.
     * @param c son las columnas del campo de minas.
     * @param b son las minas que habrán en el campo.
     */
    public static void inicialitzarElJoc(int f, int c, int b) {
        //variables globales.
        files = f;
        columnes = c;
        bombes = b;
        minesOcult = new char[f][c];
        minesVisible = new char[f][c];

        inicialitzarCampMines(minesOcult, ' ');
        inicialitzarCampMines(minesVisible, '.');
        posarBombesAleatoriament();
        comptarBombes();
        Vista.mostrarCampMines(minesOcult);
        System.out.println();
        Vista.mostrarCampMines(minesVisible);
    }

    /**
     * Método de verificacion de filas y columnas para evitar errores.
     */

    public static boolean verificarFilaColumna(int fila, int columna) {
        return fila >= 0 && columna >= 0 && fila < files && columna < columnes;
    }

    /**
     * Método para pisar una casilla, si pisas una bomba o completas el campo correctamente termina la partida.
     * @param fila fila escogida para pisar.
     * @param columna columna escogida para pisar.
     */
    public static void trepitjar(int fila, int columna) {
        if (!(verificarFilaColumna(fila, columna)) || minesVisible[fila][columna] != '.') {
            return;
        }
        trepitjarRecursivament(fila,columna);
        if (minesVisible[fila][columna] == 'B') {
            Vista.mostrarMissatge("DERROTA!!!");
            mostrarSolucio();
            jocFinalitzat = true;
        } else {
            Vista.mostrarCampMines(minesVisible);
        }
        if (comprovarVictoria()){
            Vista.mostrarMissatge("VICTORIA!!!");
            jocFinalitzat = true;
        }
    }

    /**
     * Método recursivo para pisar constantemente las casillas vacías y su alrededor.
     * @param fila fila escogida para pisar.
     * @param columna columna escogida para pisar.
     */
    public static void trepitjarRecursivament(int fila, int columna) {
        if (!verificarFilaColumna(fila, columna) || minesVisible[fila][columna] != '.') {
                return;
        }
            minesVisible[fila][columna] = minesOcult[fila][columna];

        if (minesVisible[fila][columna] == '0'){
            trepitjarRecursivament(fila - 1, columna - 1);
            trepitjarRecursivament(fila - 1, columna);
            trepitjarRecursivament(fila - 1, columna + 1);
            trepitjarRecursivament(fila, columna - 1);
            trepitjarRecursivament(fila, columna + 1);
            trepitjarRecursivament(fila + 1, columna - 1);
            trepitjarRecursivament(fila + 1, columna);
            trepitjarRecursivament(fila + 1, columna + 1);
        }
    }

    /**
     * Método para poner una bandera donde se cree que hay una bomba, si se completa el campo correctamente se termina la partida.
     * @param fila fila donde se coloca la bandera.
     * @param columna columna donde se coloca la bandera.
     */
    public static void possarBandera(int fila, int columna){
        if (!(minesVisible[fila][columna] == 'B') && minesVisible[fila][columna] == minesOcult[fila][columna]){
            Vista.mostrarMissatge("No pots posar una bandera, aquest lloc ja està trepitjat");
        }
        if (minesVisible[fila][columna] == 'B'){
            minesVisible[fila][columna] = '.';
        }else {
            minesVisible[fila][columna] = 'B';
        }
        Vista.mostrarCampMines(minesVisible);
        if (comprovarVictoria()){
            Vista.mostrarMissatge("VICTORIA!!!");
            jocFinalitzat = true;
        }

    }

    /**
     * Método para crear un campo sin ninguna mina.
     * @param campMines array deseado para crear el campo.
     * @param casella carácter deseado para rellenar el campo.
     */
    private static void inicialitzarCampMines(char[][] campMines, char casella){
        int fila = campMines.length;
        int columna = campMines[0].length;
        for (int i = 0; i < fila; ++i) {;
            for (int j = 0; j < columna ; ++j) {
                campMines[i][j] = casella;
            }
        }
    }

    /**
     * Método para llenar un campo de minas de forma aleatoria.
     */
    private static void posarBombesAleatoriament(){
        char bomba = 'B';

        for (int i = 0; i < bombes; i++){
            int posicioFila = (int)(Math.random() * files);
            int posicioColumna = (int)(Math.random() * columnes);
            while (minesOcult[posicioFila][posicioColumna] == bomba){
                posicioFila = (int)(Math.random() * files);
                posicioColumna = (int)(Math.random() * columnes);
            }
            minesOcult[posicioFila][posicioColumna] = bomba;
        }
    }

    /**
     * Método para contar las bombas que hay alrededor de una casilla y coloca ese número en dicha casilla.
     */
    private static void comptarBombes(){
        int combtadorBombes = 0;
        for (int i = 0; i < files; ++i) {
            for (int j = 0; j < columnes ; ++j) {
                if (minesOcult[i][j] != 'B'){
                    if (verificarFilaColumna(i - 1 ,j - 1) && minesOcult[i - 1][j - 1] == 'B'){
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i,j - 1) && minesOcult[i][j - 1] == 'B') {
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i + 1,j - 1) && minesOcult[i + 1][j - 1] == 'B') {
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i - 1, j) && minesOcult[i - 1][j] == 'B') {
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i + 1, j) && minesOcult[i + 1][j] == 'B') {
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i - 1,j + 1) && minesOcult[i - 1][j + 1] == 'B') {
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i,j + 1) && minesOcult[i][j + 1] == 'B') {
                        combtadorBombes++;
                    }
                    if (verificarFilaColumna(i + 1,j + 1) && minesOcult[i + 1][j + 1] == 'B') {
                        combtadorBombes++;
                    }
                    minesOcult[i][j] = (char) (combtadorBombes + '0');
                    combtadorBombes = 0;
                }

            }
        }



    }

    /**
     * Método para comprovar si se ha ganado.
     * @return devuelve true a la variable jocFinalitzat provocando el fin de la partida.
     */
    public static boolean comprovarVictoria(){
        return jocFinalitzat;
    }

    /**
     * Método para mostrar todas las bombas del campo.
     */
    private static void mostrarSolucio(){
        for (int i = 0; i < files; ++i) {
            for (int j = 0; j < columnes; ++j) {
                if (minesVisible[i][j] == 'B' && minesOcult[i][j] != 'B'){
                    minesVisible[i][j] = 'X';
                }
                if (minesOcult[i][j] == 'B'){
                    minesVisible[i][j] = minesOcult[i][j];
                }
            }
        }
        Vista.mostrarCampMines(minesVisible);
    }
}
