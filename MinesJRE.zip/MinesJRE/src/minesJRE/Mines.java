package minesJRE;
import minesJRE.controlador.Controlador;

/**
 * Clase principal donde se encuentra el main.
 */
public class Mines {
    /**
     * Método main donde se inicia la partida.
     * @param args array del método main
     */
    public static void main(String[] args) {
        Controlador.nivellJoc();
    }
}
