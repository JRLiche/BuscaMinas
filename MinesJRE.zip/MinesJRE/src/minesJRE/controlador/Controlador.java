package minesJRE.controlador;
import minesJRE.model.Model;
import minesJRE.vista.Vista;
import java.util.Scanner;

/**
 * Clase donde se encuentran los métodos de la parte de control del usuario del juego.
 */
public class Controlador {
    static Scanner scan = new Scanner(System.in);
    static int fila, files, columna, columnes, bombes;
    static String opcioUsuari, filaColumna, columnaString;

    /**
     * Método para escoger el tipo de nivel deseado.
     */

    public static void nivellJoc(){
        char nivell;
        Vista.mostrarMissatge("""
                Quin nivell vols?
                   1 - 8x8 (10 bombes)
                   2 - 16x16 (40 bombes)
                   3 - 16x30 (99 bombes)
                   S - Sortir del programa.""");
        nivell = scan.next().toUpperCase().charAt(0);
        scan.nextLine();
        switch (nivell){
            case '1':
                files = 8;
                columnes = 8;
                bombes = 10;
                jugar();
                break;
            case '2':
                files = 16;
                columnes = 16;
                bombes = 40;
                jugar();
                break;
            case '3':
                files = 16;
                columnes = 30;
                bombes = 99;
                jugar();
                break;
            case 'S':
                System.exit(0);
                break;
        }
    }

    /**
     * Método donde se encuentra la parte jugable del buscaminas.
     */
    public static void jugar() {

        Model.inicialitzarElJoc(files, columnes, bombes);

        do {
            System.out.print("Vols (T)Trepitjar, (B)Bandera o (A)Acabar? ");
            opcioUsuari = scan.nextLine().toUpperCase().trim();
            switch (opcioUsuari) {
                case "T":
                   pedirFilaColumna();
                    if (fila > files - 1 || columna > columnes - 1){
                        Vista.mostrarMissatge("La fila o la columna no existeix. Torna a provar --> ");
                        break;
                    }
                    Model.trepitjar(fila, columna);
                    break;
                case "B":
                    pedirFilaColumna();
                    if (fila > files - 1 || columna > columnes - 1){
                        Vista.mostrarMissatge("La fila o la columna no existeix. Torna a provar --> ");
                        break;
                    }
                    Model.possarBandera(fila, columna);
                    break;
                case "A":
                    System.exit(0);
            }
        } while (!Model.comprovarVictoria());
    }

    /**
     * Método para pedir las filas y columnas al usuario.
     */
    private static void pedirFilaColumna() {
        Vista.mostrarMissatge("Digues fila(Lletra) i columna(Número): ");
        filaColumna = scan.nextLine().trim().toUpperCase();
        fila = filaColumna.charAt(0);
        fila -= 65;
        String filaColumnaEspacios = filaColumna.replace(" ", "");
        columnaString = filaColumnaEspacios.substring(1);
        columna = Integer.parseInt(columnaString);
        columna -= 1;
    }
}

